export default {
    KNIGHT: 'knight',
}
