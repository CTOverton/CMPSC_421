import React, {Component} from 'react'

class slide_puzzle extends Component {
    render() {
        return (
            <div>
                <h1>slide_puzzle</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem iste nobis, pariatur possimus repellat similique? Culpa dicta enim expedita ipsum libero placeat quas reiciendis reprehenderit! Architecto eos quos rem voluptate.</p>
            </div>
        )
    }
}

export default slide_puzzle;